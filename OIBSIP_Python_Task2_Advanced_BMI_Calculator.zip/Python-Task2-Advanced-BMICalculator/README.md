# BMI Studio — Advanced BMI Calculator

**OASIS INFOBYTE · Python Programming · Task 2 · Advanced Tier**

BMI Studio is a desktop GUI application built with Python Tkinter, SQLite and Matplotlib. It calculates BMI, classifies the result, supports multiple named profiles, saves historical measurements locally and visualises each profile's trend.

## 1. OASIS task checklist mapping

| Advanced-tier requirement | Implementation |
|---|---|
| Tkinter/PyQt GUI; no command-line workflow | Tkinter desktop interface |
| Weight and height input fields + Calculate button | Included; kg and metres |
| Colour-coded BMI result | Underweight, Normal, Overweight and Obese categories |
| Multi-user named profiles | Each name gets a separate profile and history |
| SQLite / CSV historical records | SQLite database |
| Line chart of BMI trend using Matplotlib | Per-profile BMI trend chart |
| Database read/write error handling | User-facing error dialogs and repository exceptions |

The beginner-tier calculation and validation requirements are included as well.

## 2. Technology
- Python 3.10+
- Tkinter / ttk (Python standard library)
- SQLite3 (Python standard library)
- Matplotlib

## 3. Project structure

```text
Python-Task2-Advanced-BMICalculator/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── bmi_app/
│   ├── __init__.py
│   ├── calculator.py
│   ├── database.py
│   └── gui.py
├── tests/
│   ├── test_calculator.py
│   └── test_database.py
└── instance/                 # created automatically for local database
```

## 4. Run on Windows / VS Code

```powershell
py -3 --version
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

If PowerShell blocks activation:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## 5. Use the application
1. Enter a profile name, such as `Alex`.
2. Enter weight in kilograms and height in metres.
3. Click **Calculate and save**.
4. The BMI value and category appear with colour-coded feedback.
5. The record is saved to that profile's SQLite history.
6. Select another saved profile from the dropdown to view its history and trend chart.
7. Add multiple measurements over time to build a useful trend.

## 6. Calculation and categories

\[
BMI = \\frac{weight\\ (kg)}{height\\ (m)^2}
\]

- Underweight: BMI < 18.5
- Normal: 18.5–24.9
- Overweight: 25–29.9
- Obese: BMI ≥ 30

These are general adult screening categories, not a medical diagnosis. BMI does not directly measure body fat or individual health.

## 7. Data storage and privacy
The SQLite database is created at `instance/bmi_history.sqlite3` by default. It stores profile names, weight, height, calculated BMI, category and UTC record timestamps. Data stays in the local project database; this app does not send it to a remote server. Protect the computer and database file because measurements are personal information. The database is excluded from Git by `.gitignore`.

## 8. Tests

Run:
```powershell
python -m unittest discover -s tests -v
```

The tests cover BMI arithmetic, category boundaries, invalid values, multi-user record separation and history persistence. GUI rendering requires a desktop display; automated tests focus on the calculation and data layers.

## 9. GitHub submission

The OASIS PDF requires the repository name `OIBSIP` and task folder naming format:

```text
OIBSIP/Python-Task2-Advanced-BMICalculator/
```

Copy this folder into your existing public OIBSIP repository. Do not commit the SQLite database or local virtual environment.

## 10. Demo video and LinkedIn materials

### Required 2-second title card
- Name: TEJAS REDDY C R
- Track: Python Programming
- Task: Task 2 — BMI Calculator

### Suggested demo sequence
1. Show the title card for 2 seconds.
2. Launch BMI Studio.
3. Enter a profile name and valid weight/height.
4. Calculate and show the colour-coded BMI result.
5. Save a second measurement for the same profile.
6. Switch to a second named profile and save a measurement.
7. Switch between profiles to demonstrate separate histories.
8. Show the trend chart and recent record list.
9. Demonstrate invalid/empty input handling.
10. Briefly show the test command and README.

### LinkedIn post draft

> Completed my Advanced Python Programming internship project — **BMI Studio: BMI Calculator with History & Trend Visualisation**, as part of my Oasis Infobyte internship.
>
> Built using Python, Tkinter, SQLite and Matplotlib, the application calculates BMI, provides colour-coded categories, supports multiple user profiles, stores historical records and visualises BMI trends.
>
> This project helped me strengthen my Python GUI development, database integration, data validation and visualisation skills.
>
> #oasisinfobyte #python #pythonprogramming #tkinter #sqlite #matplotlib #internship

Tag the official Oasis Infobyte account as instructed by your cohort.
