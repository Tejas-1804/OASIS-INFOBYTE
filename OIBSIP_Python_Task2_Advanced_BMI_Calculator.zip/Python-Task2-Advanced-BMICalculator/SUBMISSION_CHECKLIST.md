# OASIS INFOBYTE Submission Checklist

- [x] Advanced Tkinter desktop GUI
- [x] Weight and height input
- [x] BMI formula and category classification
- [x] Input validation for non-numeric, zero, negative and non-finite values
- [x] Colour-coded result
- [x] Multiple named profiles
- [x] SQLite history persistence
- [x] Per-profile Matplotlib trend chart
- [x] Database initialization/read/write error handling
- [x] Automated unit tests
- [x] README and demo walkthrough
- [x] Git ignore rules

Before submission:
- [ ] Install Matplotlib in your local virtual environment.
- [ ] Run `python -m unittest discover -s tests -v`.
- [ ] Launch `python app.py` and test the desktop GUI.
- [ ] Record demo with required 2-second title card.
- [ ] Push to public `OIBSIP` repository under `Python-Task2-Advanced-BMICalculator/`.
- [ ] Post demo on LinkedIn with `#oasisinfobyte` and tag Oasis Infobyte.
- [ ] Comment substantively on at least two peer demo videos.
- [ ] Submit the GitHub repository link through the cohort's official form.

BMI is a screening measure, not a diagnosis. Do not commit personal measurements or the SQLite database to GitHub.
