# Test and Verification Report

## Build-time checks
- Python syntax compilation: run locally using `python -m compileall .`
- Automated tests: included in `tests/`; not represented as passing until executed locally.
- Runtime GUI: requires a desktop display and Matplotlib installation.

## Full local verification

```powershell
pip install -r requirements.txt
python -m unittest discover -s tests -v
python app.py
```

Use the GUI to save records for two different names, add multiple records for one name, switch profile selection and verify that chart/history are separate.
