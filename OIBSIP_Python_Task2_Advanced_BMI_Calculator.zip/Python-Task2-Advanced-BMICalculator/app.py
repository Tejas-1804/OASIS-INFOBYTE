from bmi_app.gui import BMICalculatorApp

def main():
    app = BMICalculatorApp()
    app.mainloop()

if __name__ == "__main__":
    main()
