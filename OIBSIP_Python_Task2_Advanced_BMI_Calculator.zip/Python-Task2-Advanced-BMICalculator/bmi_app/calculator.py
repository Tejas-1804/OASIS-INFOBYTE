import math

def calculate_bmi(weight_kg, height_m):
    """Return BMI rounded to 2 decimals; reject invalid or non-physical values."""
    try:
        weight = float(weight_kg)
        height = float(height_m)
    except (TypeError, ValueError):
        raise ValueError("Enter valid numbers for weight and height.") from None
    if not math.isfinite(weight) or not math.isfinite(height):
        raise ValueError("Weight and height must be finite numbers.")
    if weight <= 0:
        raise ValueError("Weight must be greater than zero.")
    if height <= 0:
        raise ValueError("Height must be greater than zero.")
    if weight > 1000 or height > 3:
        raise ValueError("Please check the entered measurements.")
    return round(weight / (height * height), 2)

def classify_bmi(bmi):
    value = float(bmi)
    if not math.isfinite(value) or value < 0:
        raise ValueError("BMI must be a non-negative finite number.")
    if value < 18.5:
        return "Underweight"
    if value < 25:
        return "Normal"
    if value < 30:
        return "Overweight"
    return "Obese"

def category_color(category):
    return {
        "Underweight": "#e6b85c",
        "Normal": "#39c99a",
        "Overweight": "#f0a34a",
        "Obese": "#f07183",
    }.get(category, "#8d9ab5")
