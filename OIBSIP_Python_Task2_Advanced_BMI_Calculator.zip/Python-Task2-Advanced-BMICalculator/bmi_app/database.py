import sqlite3
from pathlib import Path
from datetime import datetime, timezone

class BMIRepository:
    def __init__(self, database_path):
        self.database_path = str(database_path)
        parent = Path(self.database_path).parent
        if self.database_path != ":memory:":
            parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    def _connect(self):
        connection = sqlite3.connect(self.database_path, timeout=5)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 5000")
        return connection

    def initialize(self):
        try:
            with self._connect() as db:
                db.executescript("""
                    CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL COLLATE NOCASE UNIQUE,
                        created_at TEXT NOT NULL
                    );
                    CREATE TABLE IF NOT EXISTS bmi_records (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                        weight_kg REAL NOT NULL CHECK(weight_kg > 0),
                        height_m REAL NOT NULL CHECK(height_m > 0),
                        bmi REAL NOT NULL CHECK(bmi > 0),
                        category TEXT NOT NULL,
                        recorded_at TEXT NOT NULL
                    );
                    CREATE INDEX IF NOT EXISTS idx_bmi_user_date
                    ON bmi_records(user_id, recorded_at);
                """)
        except sqlite3.Error as exc:
            raise RuntimeError(f"Could not initialize the BMI database: {exc}") from exc

    def save_record(self, user_name, weight, height, bmi, category):
        name = (user_name or "").strip()
        if not name or len(name) > 60:
            raise ValueError("Name must contain 1–60 characters.")
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        try:
            with self._connect() as db:
                db.execute("INSERT OR IGNORE INTO users(name,created_at) VALUES(?,?)", (name, now))
                user = db.execute("SELECT id FROM users WHERE name=?", (name,)).fetchone()
                db.execute("""
                    INSERT INTO bmi_records(user_id,weight_kg,height_m,bmi,category,recorded_at)
                    VALUES(?,?,?,?,?,?)
                """, (user["id"], float(weight), float(height), float(bmi), category, now))
        except sqlite3.Error as exc:
            raise RuntimeError(f"Could not save this BMI record: {exc}") from exc

    def get_user_names(self):
        try:
            with self._connect() as db:
                rows = db.execute("SELECT name FROM users ORDER BY name COLLATE NOCASE").fetchall()
                return [row["name"] for row in rows]
        except sqlite3.Error as exc:
            raise RuntimeError(f"Could not load saved users: {exc}") from exc

    def get_history(self, user_name, limit=100):
        try:
            with self._connect() as db:
                rows = db.execute("""
                    SELECT r.weight_kg,r.height_m,r.bmi,r.category,r.recorded_at
                    FROM bmi_records r JOIN users u ON u.id=r.user_id
                    WHERE u.name=? ORDER BY r.id DESC LIMIT ?
                """, (user_name, int(limit))).fetchall()
                return [dict(row) for row in reversed(rows)]
        except sqlite3.Error as exc:
            raise RuntimeError(f"Could not load BMI history: {exc}") from exc
