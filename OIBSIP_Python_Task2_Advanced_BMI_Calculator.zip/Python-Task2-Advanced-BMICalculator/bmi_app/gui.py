import os
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from .calculator import calculate_bmi, classify_bmi, category_color
from .database import BMIRepository

class BMICalculatorApp(tk.Tk):
    BG = "#0b1020"
    PANEL = "#131c31"
    TEXT = "#eef3ff"
    MUTED = "#91a0bd"
    ACCENT = "#8b7cff"

    def __init__(self, repository=None):
        super().__init__()
        self.title("BMI Studio · Personal Health Tracker")
        self.geometry("1040x700")
        self.minsize(760, 600)
        self.configure(bg=self.BG)
        db_path = os.getenv("BMI_DATABASE_PATH", str(Path(__file__).resolve().parent.parent / "instance" / "bmi_history.sqlite3"))
        try:
            self.repository = repository or BMIRepository(db_path)
            self.db_ready = True
        except RuntimeError as exc:
            self.repository = None
            self.db_ready = False
            self.after(100, lambda: messagebox.showerror("Database error", str(exc)))
        self.last_result = None
        self._style()
        self._build()
        self._refresh_users()

    def _style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TCombobox", fieldbackground="#0d1528", background="#202b45",
                        foreground=self.TEXT, arrowcolor=self.TEXT, bordercolor="#2a3856")
        style.map("TCombobox", fieldbackground=[("readonly", "#0d1528")],
                  foreground=[("readonly", self.TEXT)])

    def _build(self):
        header = tk.Frame(self, bg=self.BG)
        header.pack(fill="x", padx=32, pady=(24, 14))
        tk.Label(header, text="BMI STUDIO", bg=self.BG, fg="#a99fff",
                 font=("Segoe UI", 10, "bold")).pack(anchor="w")
        tk.Label(header, text="Understand your progress.", bg=self.BG, fg=self.TEXT,
                 font=("Segoe UI", 25, "bold")).pack(anchor="w", pady=(4, 2))
        tk.Label(header, text="A private, local BMI journal with saved records and visual trends.",
                 bg=self.BG, fg=self.MUTED, font=("Segoe UI", 10)).pack(anchor="w")

        content = tk.Frame(self, bg=self.BG)
        content.pack(fill="both", expand=True, padx=32, pady=(8, 26))
        content.columnconfigure(0, weight=4)
        content.columnconfigure(1, weight=5)
        content.rowconfigure(0, weight=1)

        left = tk.Frame(content, bg=self.PANEL, highlightbackground="#273550", highlightthickness=1)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        right = tk.Frame(content, bg=self.PANEL, highlightbackground="#273550", highlightthickness=1)
        right.grid(row=0, column=1, sticky="nsew", padx=(12, 0))
        self._build_form(left)
        self._build_history(right)

    def _label(self, parent, text):
        tk.Label(parent, text=text, bg=self.PANEL, fg="#bdc8dc",
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(14, 6))

    def _entry(self, parent, variable, placeholder=""):
        entry = tk.Entry(parent, textvariable=variable, bg="#0c1427", fg=self.TEXT,
                         insertbackground=self.TEXT, relief="flat", highlightthickness=1,
                         highlightbackground="#2a3856", highlightcolor=self.ACCENT,
                         font=("Segoe UI", 11))
        entry.pack(fill="x", ipady=11)
        return entry

    def _build_form(self, parent):
        pad = tk.Frame(parent, bg=self.PANEL)
        pad.pack(fill="both", expand=True, padx=24, pady=22)
        tk.Label(pad, text="New measurement", bg=self.PANEL, fg=self.TEXT,
                 font=("Segoe UI", 16, "bold")).pack(anchor="w")
        tk.Label(pad, text="Enter a name to keep each person's history separate.",
                 bg=self.PANEL, fg=self.MUTED, font=("Segoe UI", 9)).pack(anchor="w", pady=(5, 8))
        self.name_var = tk.StringVar()
        self.weight_var = tk.StringVar()
        self.height_var = tk.StringVar()
        self._label(pad, "PERSON / PROFILE NAME")
        self.name_entry = self._entry(pad, self.name_var, "e.g. Alex")
        self._label(pad, "WEIGHT (KILOGRAMS)")
        self._entry(pad, self.weight_var)
        self._label(pad, "HEIGHT (METRES)")
        self._entry(pad, self.height_var)
        tk.Label(pad, text="Example: 68.5 kg and 1.72 m", bg=self.PANEL,
                 fg=self.MUTED, font=("Segoe UI", 8)).pack(anchor="w", pady=(7, 0))
        tk.Button(pad, text="Calculate and save  →", command=self.calculate,
                  bg=self.ACCENT, fg="white", activebackground="#7565ef",
                  activeforeground="white", relief="flat", cursor="hand2",
                  font=("Segoe UI", 10, "bold"), pady=13).pack(fill="x", pady=(24, 12))
        self.result_box = tk.Frame(pad, bg="#0d1629", highlightbackground="#2b3957", highlightthickness=1)
        self.result_box.pack(fill="x", pady=(4, 0))
        self.result_bmi = tk.Label(self.result_box, text="—", bg="#0d1629", fg=self.TEXT,
                                   font=("Segoe UI", 30, "bold"))
        self.result_bmi.pack(anchor="w", padx=16, pady=(10, 0))
        self.result_category = tk.Label(self.result_box, text="Your BMI result appears here",
                                        bg="#0d1629", fg=self.MUTED, font=("Segoe UI", 10, "bold"))
        self.result_category.pack(anchor="w", padx=16, pady=(0, 12))
        tk.Label(pad, text="BMI categories are general screening ranges, not a diagnosis.",
                 bg=self.PANEL, fg=self.MUTED, wraplength=330, justify="left",
                 font=("Segoe UI", 8)).pack(anchor="w", pady=(15, 0))

    def _build_history(self, parent):
        pad = tk.Frame(parent, bg=self.PANEL)
        pad.pack(fill="both", expand=True, padx=22, pady=22)
        top = tk.Frame(pad, bg=self.PANEL)
        top.pack(fill="x")
        tk.Label(top, text="Progress history", bg=self.PANEL, fg=self.TEXT,
                 font=("Segoe UI", 16, "bold")).pack(side="left")
        self.user_combo = ttk.Combobox(top, state="readonly", width=17)
        self.user_combo.pack(side="right")
        self.user_combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh_history())
        tk.Label(pad, text="Choose a saved profile to view its BMI trend.",
                 bg=self.PANEL, fg=self.MUTED, font=("Segoe UI", 9)).pack(anchor="w", pady=(6, 10))
        self.chart_host = tk.Frame(pad, bg="#0d1629", highlightbackground="#2b3957", highlightthickness=1)
        self.chart_host.pack(fill="both", expand=True)
        self.history_text = tk.Text(pad, height=7, bg="#0d1629", fg="#cbd5e8",
                                    insertbackground=self.TEXT, relief="flat",
                                    font=("Consolas", 9), state="disabled")
        self.history_text.pack(fill="x", pady=(12, 0))
        self._draw_empty_chart()

    def _draw_empty_chart(self):
        for child in self.chart_host.winfo_children():
            child.destroy()
        tk.Label(self.chart_host, text="Your trend chart will appear after saving measurements.",
                 bg="#0d1629", fg=self.MUTED, wraplength=340,
                 font=("Segoe UI", 10)).pack(expand=True, padx=20, pady=20)

    def calculate(self):
        name = self.name_var.get().strip()
        if not name or len(name) > 60:
            messagebox.showerror("Invalid name", "Enter a profile name containing 1–60 characters.")
            return
        try:
            weight = float(self.weight_var.get())
            height = float(self.height_var.get())
            bmi = calculate_bmi(weight, height)
            category = classify_bmi(bmi)
        except ValueError as exc:
            messagebox.showerror("Check your measurements", str(exc))
            return
        if not self.db_ready or self.repository is None:
            messagebox.showerror("Database unavailable", "The database is unavailable. Your result was not saved.")
            return
        try:
            self.repository.save_record(name, weight, height, bmi, category)
        except (RuntimeError, ValueError) as exc:
            messagebox.showerror("Could not save record", str(exc))
            return
        self.last_result = (bmi, category)
        self.result_bmi.config(text=f"{bmi:.2f}")
        self.result_category.config(text=category, fg=category_color(category))
        self._refresh_users(select=name)
        self.refresh_history()
        messagebox.showinfo("Saved", f"BMI {bmi:.2f} ({category}) saved for {name}.")

    def _refresh_users(self, select=None):
        if not self.db_ready:
            return
        try:
            names = self.repository.get_user_names()
            self.user_combo["values"] = names
            if select and select in names:
                self.user_combo.set(select)
            elif self.user_combo.get() not in names:
                self.user_combo.set(names[-1] if names else "")
        except RuntimeError as exc:
            messagebox.showerror("Database error", str(exc))

    def refresh_history(self):
        name = self.user_combo.get().strip()
        if not name or not self.db_ready:
            self._draw_empty_chart()
            self._set_history_text([])
            return
        try:
            records = self.repository.get_history(name)
        except RuntimeError as exc:
            messagebox.showerror("Database error", str(exc))
            return
        self._draw_chart(records)
        self._set_history_text(records)

    def _set_history_text(self, records):
        self.history_text.config(state="normal")
        self.history_text.delete("1.0", "end")
        if not records:
            self.history_text.insert("end", "No saved measurements for this profile yet.")
        else:
            for r in reversed(records[-5:]):
                stamp = r["recorded_at"].replace("T", " ")[:16]
                self.history_text.insert("end", f'{stamp}  |  BMI {r["bmi"]:.2f}  |  {r["category"]}\n')
        self.history_text.config(state="disabled")

    def _draw_chart(self, records):
        for child in self.chart_host.winfo_children():
            child.destroy()
        if not records:
            self._draw_empty_chart()
            return
        try:
            from matplotlib.figure import Figure
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
            values = [r["bmi"] for r in records]
            fig = Figure(figsize=(5.2, 3.4), dpi=100, facecolor="#0d1629")
            ax = fig.add_subplot(111)
            ax.set_facecolor("#0d1629")
            ax.plot(range(1, len(values)+1), values, marker="o", linewidth=2.2,
                    markersize=6, color="#9b8fff")
            ax.fill_between(range(1, len(values)+1), values, alpha=.12, color="#9b8fff")
            ax.set_title("BMI over time", color="#eef3ff", fontsize=12, pad=14)
            ax.set_xlabel("Measurement", color="#91a0bd")
            ax.set_ylabel("BMI", color="#91a0bd")
            ax.tick_params(colors="#91a0bd", labelsize=8)
            for spine in ax.spines.values():
                spine.set_color("#2b3957")
            ax.grid(True, color="#26334e", alpha=.55, linewidth=.6)
            fig.tight_layout(pad=2)
            canvas = FigureCanvasTkAgg(fig, master=self.chart_host)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="both", expand=True, padx=8, pady=8)
        except Exception as exc:
            tk.Label(self.chart_host, text=f"Chart could not be displayed:\n{exc}",
                     bg="#0d1629", fg="#f0a34a", wraplength=350).pack(expand=True)
