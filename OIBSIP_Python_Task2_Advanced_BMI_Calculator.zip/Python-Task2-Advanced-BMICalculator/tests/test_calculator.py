import unittest
from bmi_app.calculator import calculate_bmi, classify_bmi, category_color

class CalculatorTests(unittest.TestCase):
    def test_bmi_calculation(self):
        self.assertEqual(calculate_bmi(68.5, 1.72), 23.15)

    def test_categories_and_boundaries(self):
        self.assertEqual(classify_bmi(18.49), "Underweight")
        self.assertEqual(classify_bmi(18.5), "Normal")
        self.assertEqual(classify_bmi(24.99), "Normal")
        self.assertEqual(classify_bmi(25), "Overweight")
        self.assertEqual(classify_bmi(29.99), "Overweight")
        self.assertEqual(classify_bmi(30), "Obese")

    def test_invalid_inputs(self):
        for weight, height in [(0, 1.7), (-2, 1.7), (70, 0), (70, -1), ("x", 1.7), (float("nan"), 1.7)]:
            with self.subTest(weight=weight, height=height):
                with self.assertRaises(ValueError):
                    calculate_bmi(weight, height)

    def test_category_color(self):
        self.assertTrue(category_color("Normal").startswith("#"))

if __name__ == "__main__":
    unittest.main()
