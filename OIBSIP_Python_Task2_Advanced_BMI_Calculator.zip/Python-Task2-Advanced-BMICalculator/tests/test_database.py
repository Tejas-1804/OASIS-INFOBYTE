import tempfile
import unittest
from pathlib import Path
from bmi_app.database import BMIRepository

class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.repo = BMIRepository(Path(self.tmp.name) / "bmi.sqlite3")

    def tearDown(self):
        self.tmp.cleanup()

    def test_save_and_load_multiple_users(self):
        self.repo.save_record("Alex", 68, 1.7, 23.53, "Normal")
        self.repo.save_record("Sam", 90, 1.8, 27.78, "Overweight")
        self.repo.save_record("Alex", 69, 1.7, 23.88, "Normal")
        self.assertEqual(self.repo.get_user_names(), ["Alex", "Sam"])
        self.assertEqual(len(self.repo.get_history("Alex")), 2)
        self.assertEqual(len(self.repo.get_history("Sam")), 1)

    def test_empty_or_long_user_name(self):
        with self.assertRaises(ValueError):
            self.repo.save_record("", 70, 1.7, 24.22, "Normal")
        with self.assertRaises(ValueError):
            self.repo.save_record("x" * 61, 70, 1.7, 24.22, "Normal")

if __name__ == "__main__":
    unittest.main()
