# Relay — Advanced Real-Time Chat Application

**OASIS INFOBYTE · Python Programming · Task 5 · Advanced Tier**

Relay is a responsive, multi-room real-time chat web application built with Python, Flask, Flask-SocketIO and SQLite. It includes user registration/login, password hashing, room creation/joining, persistent room history, live messages, disconnect awareness, desktop notifications and emoji shortcode rendering.

## 1. Features mapped to the OASIS task card

| OASIS Advanced checklist | Implementation |
|---|---|
| GUI chat window (Tkinter or web app) | Responsive Flask web interface |
| Registration and login | Username/password forms backed by SQLite |
| Passwords stored in SQLite | Werkzeug scrypt password hashes; plaintext is never stored |
| Multiple chat rooms | Create a room or join an existing named room |
| Message history | Last 100 room messages load on join; messages persist in SQLite |
| In-app / desktop notifications when unfocused | Browser Notification API; user grants permission |
| Emoji shortcodes | `:smile:`, `:grin:`, `:heart:`, `:thumbsup:`, `:laugh:`, `:sad:`, `:fire:`, `:wave:`, `:tada:`, `:thinking:`, `:eyes:`, `:rocket:` |
| End-to-end awareness in README | Storage and encryption limitations documented below |

The app also implements the task card's beginner foundations: a server accepts clients, clients exchange bidirectional messages in real time, messages carry timestamps, disconnects are announced, and local execution uses `127.0.0.1`.

## 2. Technology

- Python 3.10+
- Flask 3
- Flask-SocketIO 5 (threading mode) + simple-websocket
- SQLite 3
- HTML, CSS and vanilla JavaScript
- Socket.IO browser client (loaded from the Socket.IO CDN)

## 3. Project structure

```text
Python-Task5-Advanced-ChatApplication/
├── app.py
├── chatapp/
│   ├── __init__.py
│   ├── db.py
│   ├── realtime.py
│   ├── routes.py
│   ├── security.py
│   ├── templates/
│   │   ├── auth.html
│   │   └── chat.html
│   └── static/
│       ├── app.js
│       └── style.css
├── tests/
│   └── test_app.py
├── instance/                 # SQLite database is created here
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## 4. Run locally (Windows PowerShell)

Open this project folder in VS Code. Python 3.10 or newer is recommended.

```powershell
py -3 --version
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
python app.py
```

Open **http://127.0.0.1:5000** in two browser windows (or two browsers). Register two different users, create a room in one window, then join the same room from the other. Send messages in both directions.

If PowerShell blocks activation, run this once in the current terminal:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```
Then activate the environment again.

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python app.py
```

## 5. How to use

1. Register a username (3–24 letters/numbers/underscore) and password (10–128 characters).
2. Create a room, or join a room by entering its exact name.
3. Messages appear instantly for members currently in the room.
4. Room history is loaded when you join; the latest 100 messages are returned.
5. Click **Enable notifications** and allow browser notifications to receive alerts while the tab is in the background.
6. Use emoji shortcodes such as `:smile:` or `:rocket:` in messages.
7. Sign out using the sidebar.

## 6. Database design

- `users`: unique username and password hash.
- `rooms`: globally unique room name and creator.
- `room_members`: many-to-many membership between users and rooms.
- `messages`: room, sender, body and UTC timestamp.

SQLite is created automatically at `instance/chat.sqlite3`. SQL queries use parameter binding. Foreign keys and a message-history index are enabled.

## 7. Security and end-to-end awareness

**What is stored:** usernames, password hashes, room names, room memberships, message text and message timestamps are stored in the local SQLite database.

**Password handling:** passwords are hashed with Werkzeug's scrypt password-hashing implementation. The original password is not stored. Session cookies are HTTP-only and use `SameSite=Lax`.

**What is not encrypted:** this project does **not** implement end-to-end encryption. Message bodies are stored as readable text in SQLite and are sent over the network through the web application. On localhost, traffic stays on the local machine; if deployed publicly, configure HTTPS/WSS, a strong random `SECRET_KEY`, secure cookies, a production server, database backups and access controls. The server operator can access stored messages. Do not use this demo for sensitive or confidential conversations.

**Other limitations:** the included implementation is a single-process demo using SQLite and in-memory Socket.IO room membership. For multi-worker production deployments, use a shared Socket.IO message queue (e.g. Redis), stronger rate limiting, CSRF protection, account recovery, email verification, moderation/reporting, retention controls and operational monitoring. Desktop notifications require browser permission and may be restricted by browser/OS settings.

## 8. Tests

Run the automated test suite:

```powershell
python -m unittest discover -s tests -v
```

The tests cover registration/login/logout, duplicate usernames, input validation, health endpoint, room creation/joining, emoji conversion and persisted message delivery. Test results depend on your Python environment and installed dependencies; run the command locally before submission.

## 9. Troubleshooting

- **`No module named flask_socketio`**: activate `.venv`, then run `pip install -r requirements.txt`.
- **Port 5000 already in use**: set `PORT=5001` in `.env` or run `$env:PORT=5001; python app.py`.
- **No desktop alerts**: use a supported browser, click Enable notifications, and grant permission. Keep the app open in a browser tab.
- **Room is not visible**: create/join it while signed in. Room names are shared; a user joins the room on first entry.
- **WebSocket fallback**: Socket.IO can use polling when a WebSocket transport is unavailable.

## 10. Demo video and LinkedIn submission materials

### 2-second title card
Display:
- **Name:** TEJAS REDDY C R
- **Track:** Python Programming
- **Task:** Task 5 — Advanced Chat Application

### Suggested 2–3 minute walkthrough
1. Show the title card for 2 seconds.
2. Register User A and User B in separate browser sessions.
3. Create a room named `project-team` as User A.
4. Join `project-team` as User B.
5. Send messages both ways and demonstrate timestamps.
6. Send `Hello :smile: :rocket:` and show emoji rendering.
7. Refresh/rejoin the room to show persisted history.
8. Enable desktop notifications, switch away from the tab, and send a message from the other user.
9. Sign out and show the login page.
10. Briefly show the test command and README security transparency section.

### LinkedIn post draft

> Excited to share my Advanced Python Programming internship project at Oasis Infobyte — **Relay, a Real-Time Chat Application**.
>
> Built with Python, Flask, Flask-SocketIO and SQLite, Relay supports secure password hashing, multiple chat rooms, real-time messaging, persistent message history, emoji shortcodes and browser notifications.
>
> This project strengthened my understanding of Python networking, event-driven communication, database design and web application security.
>
> #oasisinfobyte #python #pythonprogramming #flask #socketio #webdevelopment #internship

Tag the official Oasis Infobyte account as required by your cohort instructions.

## 11. GitHub submission

The PDF requires one public repository named **OIBSIP**, with this task folder naming convention:

```text
OIBSIP/Python-Task5-Advanced-ChatApplication/
```

Copy this project folder into your existing `OIBSIP` repository, commit the source, README and tests, then push to GitHub. Do not commit `.env`, real secrets, or the SQLite database.
