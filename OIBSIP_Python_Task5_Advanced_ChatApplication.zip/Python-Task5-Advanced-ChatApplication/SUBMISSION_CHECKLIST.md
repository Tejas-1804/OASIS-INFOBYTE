# OASIS INFOBYTE Submission Checklist

## Project deliverables
- [x] Advanced web-based GUI chat client
- [x] Flask server and Socket.IO real-time event layer
- [x] SQLite persistence for users, rooms, memberships and messages
- [x] Password hashing (scrypt via Werkzeug)
- [x] Multiple named rooms
- [x] Room history on join (latest 100)
- [x] UTC message timestamps
- [x] Disconnect announcements to room members
- [x] Browser notifications (permission-based)
- [x] Emoji shortcode conversion
- [x] README security transparency section
- [x] Automated unittest suite
- [x] Git ignore and environment example

## Before you submit
- [ ] Install dependencies on your own computer.
- [ ] Run `python -m unittest discover -s tests -v` and confirm all tests pass.
- [ ] Run the app and test with two separate browser sessions.
- [ ] Record the demo video with the required 2-second title card:
      TEJAS REDDY C R · Python Programming · Task 5 — Chat Application.
- [ ] Push this folder into your public `OIBSIP` GitHub repository using the required path.
- [ ] Publish the demo video on LinkedIn, tag Oasis Infobyte and include `#oasisinfobyte`.
- [ ] Review two other interns' demo videos and leave substantive comments.
- [ ] Submit the repository link through the official cohort submission form.

Note: LinkedIn posting, peer evaluation, GitHub pushing and the official submission form require your own account access and cannot be completed from this source bundle.
