import os
from flask import Flask
from flask_socketio import SocketIO
from .db import init_db
from .routes import web
from .realtime import register_socket_events

socketio = SocketIO(cors_allowed_origins=[], async_mode="threading", logger=False, engineio_logger=False)

def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.update(
        SECRET_KEY=os.getenv("SECRET_KEY", "dev-only-change-this-secret-before-deploying"),
        DATABASE=os.getenv("DATABASE_PATH", os.path.join(app.instance_path, "chat.sqlite3")),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.getenv("COOKIE_SECURE", "false").lower() == "true",
        MAX_CONTENT_LENGTH=1 * 1024 * 1024,
    )
    if test_config:
        app.config.update(test_config)
    os.makedirs(app.instance_path, exist_ok=True)
    init_db(app)
    app.register_blueprint(web)
    socketio.init_app(app)
    register_socket_events(socketio)
    return app
