import re
from datetime import datetime, timezone
from flask import session, request
from flask_socketio import join_room, leave_room, emit
from .db import get_db

ROOM_RE = re.compile(r"^[A-Za-z0-9 _-]{2,32}$")
SHORTCODES = {
    ":smile:": "😄", ":grin:": "😁", ":heart:": "❤️", ":thumbsup:": "👍",
    ":laugh:": "😂", ":sad:": "😢", ":fire:": "🔥", ":wave:": "👋",
    ":tada:": "🎉", ":thinking:": "🤔", ":eyes:": "👀", ":rocket:": "🚀",
}

def render_emoji(text):
    for code, emoji in SHORTCODES.items():
        text = text.replace(code, emoji)
    return text

def register_socket_events(socketio):
    @socketio.on("connect")
    def on_connect(auth=None):
        if "user_id" not in session:
            return False
        emit("system", {"message": f"{session['username']} connected.", "kind": "info"})

    @socketio.on("create_room")
    def create_room(data):
        if "user_id" not in session:
            emit("error_message", {"message": "Please log in again."}); return
        name = (data or {}).get("name", "").strip()
        if not ROOM_RE.fullmatch(name):
            emit("error_message", {"message": "Room names must be 2–32 characters (letters, numbers, spaces, _ or -)."}); return
        db = get_db()
        try:
            cur = db.execute("INSERT INTO rooms(name,created_by) VALUES(?,?)", (name, session["user_id"]))
            room_id = cur.lastrowid
            db.execute("INSERT INTO room_members(room_id,user_id) VALUES(?,?)", (room_id, session["user_id"]))
            db.commit()
        except Exception:
            db.rollback()
            row = db.execute("SELECT id FROM rooms WHERE name=?", (name,)).fetchone()
            if not row:
                emit("error_message", {"message": "Could not create room."}); return
            room_id = row["id"]
            db.execute("INSERT OR IGNORE INTO room_members(room_id,user_id) VALUES(?,?)", (room_id, session["user_id"]))
            db.commit()
        emit("room_created", {"id": room_id, "name": name})

    @socketio.on("join_room")
    def join_chat_room(data):
        if "user_id" not in session:
            emit("error_message", {"message": "Authentication required."}); return
        name = (data or {}).get("name", "").strip()
        row = get_db().execute("SELECT id,name FROM rooms WHERE name=?", (name,)).fetchone()
        if not row:
            emit("error_message", {"message": "Room not found. Create it first."}); return
        db = get_db()
        db.execute("INSERT OR IGNORE INTO room_members(room_id,user_id) VALUES(?,?)", (row["id"], session["user_id"]))
        db.commit()
        room_key = f"room:{row['id']}"
        join_room(room_key)
        history = get_db().execute("""
          SELECT m.id,m.body,m.created_at,u.username
          FROM messages m JOIN users u ON u.id=m.user_id
          WHERE m.room_id=? ORDER BY m.id DESC LIMIT 100
        """, (row["id"],)).fetchall()
        emit("room_history", {
            "room": row["name"],
            "messages": [dict(m) for m in reversed(history)]
        })
        emit("system", {"message": f"{session['username']} joined #{row['name']}.", "kind": "info"}, to=room_key, include_self=False)

    @socketio.on("leave_room")
    def leave_chat_room(data):
        room_id = (data or {}).get("room_id")
        if room_id:
            leave_room(f"room:{int(room_id)}")

    @socketio.on("send_message")
    def send_message(data):
        if "user_id" not in session:
            emit("error_message", {"message": "Authentication required."}); return
        body = (data or {}).get("body", "")
        room_id = (data or {}).get("room_id")
        if not isinstance(body, str) or not body.strip() or len(body) > 2000:
            emit("error_message", {"message": "Message must be between 1 and 2000 characters."}); return
        try:
            room_id = int(room_id)
        except (TypeError, ValueError):
            emit("error_message", {"message": "Select a room first."}); return
        member = get_db().execute("SELECT 1 FROM room_members WHERE room_id=? AND user_id=?",
                                  (room_id, session["user_id"])).fetchone()
        if not member:
            emit("error_message", {"message": "Join this room before sending messages."}); return
        body = render_emoji(body.strip())
        db = get_db()
        cur = db.execute("INSERT INTO messages(room_id,user_id,body) VALUES(?,?,?)",
                         (room_id, session["user_id"], body))
        db.commit()
        row = db.execute("""
          SELECT m.id,m.body,m.created_at,u.username
          FROM messages m JOIN users u ON u.id=m.user_id WHERE m.id=?
        """, (cur.lastrowid,)).fetchone()
        payload = dict(row)
        payload["mine"] = True
        socketio.emit("new_message", payload, to=f"room:{room_id}")

    @socketio.on("disconnect")
    def on_disconnect(reason=None):
        username = session.get("username")
        if username:
            # Notify every room this socket had joined before it disappears.
            for joined in socketio.server.rooms(request.sid, namespace="/") or []:
                if isinstance(joined, str) and joined.startswith("room:"):
                    socketio.emit(
                        "system",
                        {"message": f"{username} disconnected.", "kind": "info"},
                        to=joined,
                        skip_sid=request.sid,
                    )
