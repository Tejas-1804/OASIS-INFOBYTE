import re
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from .db import get_db
from .security import validate_credentials, hash_password, verify_password

web = Blueprint("web", __name__)
ROOM_RE = re.compile(r"^[A-Za-z0-9 _-]{2,32}$")

@web.get("/")
def index():
    if "user_id" not in session:
        return redirect(url_for("web.login"))
    return render_template("chat.html", username=session["username"])

@web.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        error = validate_credentials(username, password)
        if error:
            flash(error, "error")
            return render_template("auth.html", mode="register")
        db = get_db()
        try:
            cur = db.execute("INSERT INTO users(username,password_hash) VALUES(?,?)",
                             (username, hash_password(password)))
            db.commit()
        except Exception:
            db.rollback()
            flash("That username is already taken. Choose another.", "error")
            return render_template("auth.html", mode="register")
        session.clear()
        session["user_id"], session["username"] = cur.lastrowid, username
        return redirect(url_for("web.index"))
    return render_template("auth.html", mode="register")

@web.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if not user or not verify_password(user["password_hash"], password):
            flash("Invalid username or password.", "error")
            return render_template("auth.html", mode="login")
        session.clear()
        session["user_id"], session["username"] = user["id"], user["username"]
        return redirect(url_for("web.index"))
    return render_template("auth.html", mode="login")

@web.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("web.login"))

@web.get("/api/rooms")
def rooms():
    if "user_id" not in session:
        return jsonify({"error": "Authentication required"}), 401
    rows = get_db().execute("""
      SELECT r.id,r.name,
        (SELECT COUNT(*) FROM messages m WHERE m.room_id=r.id) AS message_count
      FROM rooms r JOIN room_members rm ON rm.room_id=r.id
      WHERE rm.user_id=? ORDER BY r.name COLLATE NOCASE
    """, (session["user_id"],)).fetchall()
    return jsonify([dict(r) for r in rows])

@web.get("/health")
def health():
    get_db().execute("SELECT 1").fetchone()
    return jsonify({"status": "ok"})
