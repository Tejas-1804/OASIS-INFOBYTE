import re
from werkzeug.security import generate_password_hash, check_password_hash

USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,24}$")

def validate_credentials(username, password):
    if not isinstance(username, str) or not USERNAME_RE.fullmatch(username.strip()):
        return "Username must be 3–24 characters (letters, numbers, underscore)."
    if not isinstance(password, str) or len(password) < 10:
        return "Password must contain at least 10 characters."
    if len(password) > 128:
        return "Password is too long."
    return None

def hash_password(password):
    return generate_password_hash(password, method="scrypt")

def verify_password(password_hash, password):
    return check_password_hash(password_hash, password)
