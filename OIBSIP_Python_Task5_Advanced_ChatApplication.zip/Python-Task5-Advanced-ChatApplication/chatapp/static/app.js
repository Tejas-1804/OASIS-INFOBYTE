(() => {
  const $ = (id) => document.getElementById(id);
  let socket, activeRoom = null, activeRoomName = null;
  const roomList = $("room-list"), messages = $("messages");
  const toast = (msg) => { $("toast").textContent = msg; $("toast").classList.remove("hidden"); setTimeout(()=>$("toast").classList.add("hidden"), 3000); };
  const safe = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const time = (s) => { const d = new Date(s); return Number.isNaN(d.getTime()) ? "" : d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}); };

  async function loadRooms() {
    const res = await fetch("/api/rooms");
    if (!res.ok) { location.href="/login"; return; }
    const rooms = await res.json();
    roomList.innerHTML = "";
    rooms.forEach(r => {
      const b = document.createElement("button");
      b.className = "room-item" + (activeRoom === r.id ? " active" : "");
      b.innerHTML = `<span class="hash">#</span><span>${safe(r.name)}</span><span class="room-count">${r.message_count}</span>`;
      b.addEventListener("click", () => joinRoom(r.name));
      roomList.appendChild(b);
    });
    if (!rooms.length) roomList.innerHTML = '<p class="muted small-text" style="padding:8px;font-size:11px">No rooms yet. Create one to begin.</p>';
  }

  function connect() {
    socket = io({transports:["websocket","polling"]});
    socket.on("connect", () => { $("connection").classList.add("connected"); $("connection").innerHTML="<i></i> Connected"; });
    socket.on("disconnect", () => { $("connection").classList.remove("connected"); $("connection").innerHTML="<i></i> Reconnecting"; });
    socket.on("connect_error", () => toast("Connection issue. Retrying…"));
    socket.on("error_message", d => toast(d.message));
    socket.on("room_created", d => { toast(`Room #${d.name} is ready.`); loadRooms().then(()=>joinRoom(d.name)); });
    socket.on("room_history", d => {
      messages.innerHTML = "";
      activeRoomName = d.room; $("room-title").textContent = "# " + d.room;
      $("welcome").classList.add("hidden"); $("chat-panel").classList.remove("hidden");
      d.messages.forEach(m => addMessage(m, false));
      messages.scrollTop = messages.scrollHeight;
      loadRooms();
    });
    socket.on("new_message", m => {
      addMessage(m, true);
      if (document.hidden && m.username !== window.RELAY_USERNAME) notify(m);
    });
    socket.on("system", d => { if (activeRoom) addSystem(d.message); });
  }

  function joinRoom(name) { if (!socket || !socket.connected) { toast("Connecting… please try again."); return; } socket.emit("join_room", {name}); }
  function addMessage(m, scroll=true) {
    const mine = m.username === window.RELAY_USERNAME;
    const el = document.createElement("article");
    el.className = "message" + (mine ? " mine" : "");
    el.innerHTML = `<div class="message-meta"><strong>${safe(m.username)}</strong><span>${safe(time(m.created_at))}</span></div><div class="bubble">${safe(m.body)}</div>`;
    messages.appendChild(el);
    if (scroll) messages.scrollTop = messages.scrollHeight;
  }
  function addSystem(msg) { const el=document.createElement("div"); el.className="system-message"; el.textContent=msg; messages.appendChild(el); messages.scrollTop=messages.scrollHeight; }
  function notify(m) {
    if ("Notification" in window && Notification.permission === "granted") {
      const n = new Notification(`New message in #${activeRoomName || "Relay"}`, {body:`${m.username}: ${m.body}`});
      n.onclick = () => { window.focus(); n.close(); };
    }
  }
  function openModal() { $("room-modal").classList.remove("hidden"); $("room-name").focus(); }
  function closeModal() { $("room-modal").classList.add("hidden"); }
  $("create-room-open").addEventListener("click",openModal);
  $("welcome-create").addEventListener("click",openModal);
  $("modal-close").addEventListener("click",closeModal);
  $("modal-cancel").addEventListener("click",closeModal);
  $("room-form").addEventListener("submit", e => {
    e.preventDefault(); const name=$("room-name").value.trim();
    if (name.length < 2) return;
    socket.emit("create_room",{name}); closeModal(); $("room-name").value="";
  });
  $("message-form").addEventListener("submit", e => {
    e.preventDefault(); const input=$("message-input"), body=input.value.trim();
    if (!body || !activeRoom) return;
    socket.emit("send_message",{room_id:activeRoom,body}); input.value=""; input.focus();
  });
  $("notify-btn").addEventListener("click", async () => {
    if (!("Notification" in window)) { toast("This browser does not support desktop notifications."); return; }
    const permission=await Notification.requestPermission();
    toast(permission === "granted" ? "Desktop notifications enabled." : "Notification permission was not granted.");
  });
  // Socket server sends room history; resolve room ID from the authenticated user's room list.
  const originalJoin = joinRoom;
  joinRoom = async (name) => {
    const res=await fetch("/api/rooms"), rooms=await res.json();
    let room=rooms.find(r=>r.name.toLowerCase()===name.toLowerCase());
    if (!room) { socket.emit("join_room",{name}); return; }
    if (activeRoom && activeRoom !== room.id) socket.emit("leave_room",{room_id:activeRoom});
    activeRoom=room.id; originalJoin(name);
    [...roomList.children].forEach(el=>el.classList.toggle("active",el.textContent.includes(name)));
  };
  window.RELAY_USERNAME = document.querySelector(".profile strong")?.textContent || "";
  connect(); loadRooms();
})();
