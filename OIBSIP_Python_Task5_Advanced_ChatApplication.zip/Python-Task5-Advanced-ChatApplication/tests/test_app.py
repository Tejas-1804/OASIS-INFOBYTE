import tempfile
import unittest
from pathlib import Path
from chatapp import create_app, socketio

class RelayTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.app = create_app({
            "TESTING": True, "SECRET_KEY": "test-secret",
            "DATABASE": str(Path(self.tmp.name) / "test.sqlite3"),
        })
        self.client = self.app.test_client()

    def tearDown(self):
        self.tmp.cleanup()

    def register(self, username):
        return self.client.post("/register", data={"username": username, "password": "StrongPass123!"}, follow_redirects=True)

    def test_register_login_and_logout(self):
        response = self.register("alice_01")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Choose a room", response.data)
        self.client.post("/logout")
        response = self.client.post("/login", data={"username":"alice_01","password":"StrongPass123!"}, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.client.post("/logout")
        self.assertEqual(self.client.get("/api/rooms").status_code, 401)

    def test_duplicate_user_rejected(self):
        self.register("alice_01")
        response = self.client.post("/register", data={"username":"alice_01","password":"StrongPass123!"})
        self.assertIn(b"already taken", response.data)

    def test_invalid_credentials(self):
        response = self.client.post("/register", data={"username":"ab","password":"short"})
        self.assertIn(b"Username must", response.data)

    def test_health(self):
        self.assertEqual(self.client.get("/health").json, {"status":"ok"})

    def test_room_create_join_and_message_persistence(self):
        self.register("alice_01")
        socket_client = socketio.test_client(self.app, flask_test_client=self.client)
        socket_client.emit("create_room", {"name":"engineering"})
        events = socket_client.get_received()
        self.assertTrue(any(e["name"] == "room_created" for e in events))
        socket_client.emit("join_room", {"name":"engineering"})
        history = socket_client.get_received()
        self.assertTrue(any(e["name"] == "room_history" for e in history))
        with self.app.test_request_context():
            from chatapp.db import get_db
            room = get_db().execute("SELECT id FROM rooms WHERE name='engineering'").fetchone()
            room_id = room["id"]
        socket_client.emit("send_message", {"room_id":room_id,"body":"Hello :smile:"})
        events = socket_client.get_received()
        message = next(e["args"][0] for e in events if e["name"]=="new_message")
        self.assertEqual(message["body"], "Hello 😄")
        socket_client.disconnect()

if __name__ == "__main__":
    unittest.main()
